﻿using crud.Models;
using Microsoft.EntityFrameworkCore;

namespace crud.Data
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto>options) 
            : base(options)
        { }

        public DbSet<Usuario> Usuarios { get; set; }

    }
}
